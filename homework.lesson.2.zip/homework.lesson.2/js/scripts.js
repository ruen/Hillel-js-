
// 1 task
let number1 = 3;
number2 = number1 * 3;
number3 = number1 + number2;
alert(number1);
alert(number2);
alert(number3);
// end 1 task

// 2 task
let firstName = prompt('Имя' + '');
let lastName = prompt('Фамилия' + '');
alert('What’s up' + ' ' + firstName + ' ' + lastName);
// end 2 task

// 3 task
let x = prompt('Число X' + '');
let y = prompt('Число Y' + '');
alert('Произведение =' + ' ' + x * y);
alert('Частное =' + ' ' + x / y);
alert('Разность =' + ' ' + (x - y));
alert('Сумма =' + ' ' + (+x + +y));
// end 3 task

// 4 task
let workingHours = prompt('Количество рабочих часов в день');
let workingDays = prompt('Количество рабочих дней в неделю');
let hourlyRate = prompt('Рейт за час');
alert('Ваша заработная плата за июль составляет -' + ' ' + ((workingHours * workingDays * hourlyRate) * 4) + ' ' + 'эфиопских тугриков');
// end 4 task

// 5 task
let number = prompt('Введите ваше число' + '');
if(number % 2) alert('Ваше число не чётное');
else alert('Ваше число чётное');
// end 5 task

// 6 task
let number = prompt('Введите ваше значение' + '');
if(number / 0) alert('Ваше значение является числом');
else alert('Ваше значение не является числом');
// end 6 task

// 7 task
let randomNumber = (Math.round(Math.random() * 100));
let userNumber = prompt('Введите ваше число' + '');
if(randomNumber <= userNumber) alert('Введенное вами число больше нашего');
else alert('Введённое вами число меньше нашего');
alert('Наше число' + ' ' + '=' + ' ' + randomNumber);
alert('Ваше число' + ' ' + '=' + ' ' + userNumber);
// end 7 task

// 8 task
let str = 'Мне нравится изучать Front-end';
let strUser = prompt('Мне нравится изучать');
alert(str.includes(strUser));
str = str.slice(0, 21);
let result = str + strUser;
alert(result);
// end 8 task
